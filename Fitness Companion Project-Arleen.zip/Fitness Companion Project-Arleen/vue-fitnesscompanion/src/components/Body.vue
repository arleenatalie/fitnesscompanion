<template>
    <v-container>
        <h3>Please select workout type:</h3>
        <v-row justify="center">
            <v-col cols="6">
                <v-card
                class="mx-auto"
                max-width="500px"
                justify="center">
                    <v-img
                    class="white--text align-end"
                    height="400px"
                    src="../assets/personal.jpg"
                    >
                    <v-card-title>Personal Workout</v-card-title>
                    </v-img>
                    <v-card-text class="text--primary">
                    <div>Your personal and customized workout</div>
                    </v-card-text>

                    <v-card-actions>
                        <v-btn color="orange" text>
                            <router-link :to="{name: 'PersonalWorkout'}">See More</router-link>
                        </v-btn>
                    </v-card-actions>
                </v-card>
            </v-col>
            <v-col cols="6">
                <v-card
                class="mx-auto"
                max-width="500px"
                justify="center">
                    <v-img
                    class="white--text align-end"
                    height="400px"
                    src="../assets/hero.jpg"
                    >
                    <v-card-title>Hero Workout</v-card-title>
                    </v-img>
                    <v-card-text class="text--primary">
                    <div>Your precompiled and ready to use workout</div>
                    </v-card-text>

                    <v-card-actions>
                        <v-btn color="orange" text>
                            <router-link :to="{name: 'HeroWorkout'}">See More</router-link>
                        </v-btn>
                    </v-card-actions>
                </v-card>
            </v-col>
            
        </v-row>
    </v-container>
</template>