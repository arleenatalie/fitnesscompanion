<template>
    <div id="personal">
        <v-container>
            <h2>Your Daily Personal Workout</h2>

            <div id="workoutlist">
                <p v-for="personal in personals.slice().reverse()"
                :key="personal.personalId">
                    <label>
                        <input type="checkbox">
                        <span>{{personal.name}}</span>
                    </label>
                </p>
            </div>

        </v-container>
    </div>
</template>


<script>
import axios from 'axios';

export default {   
    name:'personal',

    data:() => ({
        personals: []
    }),
    mounted() {
        this.loadPersonal()
    },
    methods: {
        loadPersonal(){
            axios.get('http://localhost:5000/personal-workout')
            .then(res => {
                this.personals = res.data
                console.log(this.personals)
            }).catch(err => {console.log(err)})
        }
    },
  
}
</script>
