<template>
    <div class="header">
        <v-app-bar
        color="indigo"
        >
    
            <v-btn>
                <router-link to="/">Home</router-link>
            </v-btn>
            <v-col
                cols="auto"
            >
            </v-col>
            <v-btn>
                <router-link to="/about">About</router-link>
            </v-btn>

            <!-- spacer -->
            <v-col
                cols="auto"
                lg="3"
            >
            </v-col>

            <v-toolbar-title class="white--text font-weight-bold">
            MY FITNESS COMPANION
            </v-toolbar-title>

        </v-app-bar>
    </div>

</template>