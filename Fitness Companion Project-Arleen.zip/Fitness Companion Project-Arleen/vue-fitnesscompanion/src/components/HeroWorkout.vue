<template>
    <div class="hero">
        <div class="container">
            <!-- Search -->
            <div class="search-wrapper">
                <label>Search :   </label>
                <input type="text" v-model="search" placeholder="search workout.."/>
            </div>

            <!-- Modal -->
            <v-dialog max-width="600" v-model="modalVisible" id="heroModal">
                <v-card>
                    <v-card-title class="headline">{{modalData.name}}</v-card-title>
                    <v-card-text>
                    <hr>
                    <v-data-table
                            :headers="headers"
                            :items="modalData.training"
                    >
                    </v-data-table>
                    </v-card-text>
                    <v-card-actions>
                        <v-btn
                        color="primary"
                        text
                        @click="modalVisible= false"
                        >
                        Close
                        </v-btn>
                    </v-card-actions>
                </v-card>
            </v-dialog>

            <!-- Displayed card -->
            <div class="wrapper">
                <v-row>
                    <v-col cols="4" v-for="hero in filteredHeroes" :key="hero.heroId">
                        <v-card>
                            <v-img
                            src="../assets/hero.jpg"
                            height="200px"
                            ></v-img>

                            <v-card-title>
                            {{hero.name}}
                            </v-card-title>

                            <v-card-actions>

                                <!-- <v-btn @click="openModal(hero)">Details</v-btn> -->
                                <v-btn @click="openModal(hero)">
                                    Details
                                </v-btn>
                                
                                <v-btn
                                    icon
                                    @click="toggle(hero)"
                                >
                                    <v-icon>{{'mdi-chevron-down' }}</v-icon>
                                </v-btn>
                            </v-card-actions>
                            <v-expand-transition>
                                <div v-show="hero.show">
                                    <v-divider></v-divider>

                                    <v-card-text>
                                        {{hero.detail}}
                                    </v-card-text>
                                </div>
                            </v-expand-transition>
                            
                        </v-card>
                    </v-col>
                </v-row>
            </div>
        </div>
    </div>
</template>

<script>
import axios from 'axios';

export default {
    name: 'hero',

    data:() => ({
        modalVisible: false,
        modalData: {},
        search: "",
        headers: [
            {
                text: 'Exercise',
                align: 'start',
                sortable: false,
                value: 'exerciseName',
            },
            { text: 'Wram Up', value: 'wramUp' },
            { text: 'Working Set', value: 'workingSet' },
            { text: 'Rest Period', value: 'restPeriod' }
        ],
        heroes: []
    }),
    mounted() {
        this.loadHeroes()
    },

    methods: {
        loadHeroes (){
            axios.get('http://localhost:5000/hero-workout')
            .then(res => {
                this.heroes = res.data
                console.log(this.heroes)

            }).catch(err => console.log(err)) 
        },
        openModal(params) {
            this.modalData = params;
            this.modalVisible = true;
        },
        toggle: function (hero) {
        hero.show = !hero.show;
        }
    },
    computed: {
        filteredHeroes() {
            return this.heroes.filter(hero => {
                return hero.name.toLowerCase().includes(this.search.toLowerCase())
            })
        }
    }
}
</script>
